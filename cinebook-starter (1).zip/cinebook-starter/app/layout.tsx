import './globals.css';
import type {Metadata} from 'next';
export const metadata:Metadata={title:'Cinebook MN — Киноны ертөнц',description:'Кино үзэж, үнэлж, сэтгэгдэл бичиж, үзэх киноны жагсаалт үүсгэ.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="mn"><body>{children}<footer className="footer">CINEBOOK MN · Энэхүү бүтээгдэхүүн нь TMDB-ийн API-г ашигладаг боловч TMDB-ээр баталгаажаагүй, ивээн тэтгэгдээгүй.</footer></body></html>}
