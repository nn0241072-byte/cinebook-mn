import {NextResponse} from 'next/server';
import {tmdb} from '../../../../lib/tmdb';
export async function GET(_request:Request,{params}:{params:Promise<{id:string}>}){
 const {id}=await params;
 if(!/^\d+$/.test(id)) return NextResponse.json({error:'Буруу ID'}, {status:400});
 try{return NextResponse.json(await tmdb(`/movie/${id}`))}catch(e){return NextResponse.json({error:e instanceof Error?e.message:'Алдаа'}, {status:500})}
}
